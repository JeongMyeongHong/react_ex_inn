import React from "react"
import {useRoutes} from 'react-router-dom'
import Home from "./pages/Home";
import {BoardList, BoardEdit, Login, LuckyBoard} from "./components";


export default function App() {
    return useRoutes([
        {path: "/", element: <Home/>},
        {path: "oauth2/kakao/callback/:token/:expirationTime/:nickname", element: <LuckyBoard/>},
        {path: "board/list", element: <BoardList/>},
        {path: "board/edit/:boardID", element: <BoardEdit/>},
        {path: "login", element: <Login/>},
    ]);
}