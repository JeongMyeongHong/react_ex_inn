import React, {useEffect} from "react";
import Layout from "../containers/Layout";
import { logout } from '../api'
import { useParams } from 'react-router-dom';
import { useCookies } from 'react-cookie';

export function LuckyBoard() {

    const {token, expirationTime, nickname } = useParams([])
    const [cookies, setCookie, removeCookie] = useCookies(['accessToken']);

    const logoutButton = async (e) => {
        // e.preventdefault()
        removeCookie('accessToken');
        window.location.href('/luckyBoard')
        // alert(cookies.accessToken)
        // await logout(token).then(res => {
        //     console.log("ㅎㅇ")
        // })
        //     .catch(err => {
        //         console.log(`에러 발생 :  ${err}`)
        //     })
    }

    useEffect(() => {
        if (!token || !expirationTime || !nickname) return;
        const now = new Date().getTime();
        const expires = new Date(now + parseInt(expirationTime) * 1000);

        setCookie('accessToken', token, {expires, path: '/'});
        // window.location.href = `/login`
        }, [token]);


    return (<Layout>
        <h1>{nickname} 하이</h1>
    </Layout>)
}